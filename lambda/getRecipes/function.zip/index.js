const pg = require('pg');

exports.handler = async event => {
  const body = JSON.parse(event.body);
  const { ingredients } = body;

  const pool = new pg.Pool({
    connectionString:
      'postgres://lwstubhd:xUWDf62nGsqN8WZ0nG2N3hZ73eDg5JdG@drona.db.elephantsql.com/lwstubhd',
  });

  const client = await pool.connect();

  if (!ingredients || !Array.isArray(ingredients))
    return next({ message: { err: 'No ingredients supplied' } });

  let sqlIn = '';

  ingredients.forEach(v => {
    sqlIn += `'${v}',`;
  });

  sqlIn = sqlIn.slice(0, -1);

  const sql = `
  select  r.id, r.name, r.websiteurl, r.imagepath, r.headline, r.description,
          r.category, r.difficulty, r.calories, r.preptime, r.totaltime,
          r.favoritescount, r.averagerating, 
          row_number() over(partition by r.name order by r.favoritescount desc) as rn
  from    ingredients i
  join    recipe_ingredients ri on i.id = ri.ingredient_id
  join    recipes r on ri.recipe_id = r.id
  where   i.name in (${sqlIn}) and i.pantry = FALSE
  group by r.id, r.name, r.websiteUrl, r.imagePath, r.headline, r.description,
          r.category, r.difficulty, r.calories, r.prepTime, r.totalTime,
          r.favoritesCount, r.averageRating
  having  r.totalingredients = count(*)
  order by r.favoritesCount desc, ratingsCount desc, averageRating desc;`;

  const results = await client.query(sql);

  client.release();
  // TODO implement
  const response = {
    statusCode: 200,
    body: JSON.stringify(results.rows),
  };
  return response;
};
